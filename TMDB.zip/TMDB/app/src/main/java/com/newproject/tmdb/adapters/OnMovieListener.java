package com.newproject.tmdb.adapters;

public interface OnMovieListener {

    void onMovieClick(int position);

    void onCategoryClick(String category);


}
