package com.newproject.tmdb.utils;

public class Credentials {

    public static final String BASE_URL  = "https://api.themoviedb.org/";

    public static final String API_KEY = "9611ad116cf8e918fd77cfebc08a7c41";
}
